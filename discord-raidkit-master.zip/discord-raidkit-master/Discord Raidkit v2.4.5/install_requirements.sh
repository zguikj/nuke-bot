#!/bin/bash
python3 -m pip install bs4 colorama discord nest_asyncio requests selenium ujson webdriver_manager